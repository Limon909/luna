 "use client";

import { useState } from "react";
import {
  Activity, ArrowDownRight, ArrowRight, Bell, Check, ChevronRight,
  CircleHelp, Coins, Crown, Gamepad2, Gem, Globe, Home, Image,
  Menu, Pickaxe, Plus, ShieldCheck, Sparkles, Trophy, Users, Wallet,
  X, Zap
} from "lucide-react";

type Section = "Dashboard" | "NFT Garage" | "Mining Pool" | "Quests" | "Friends" | "Leaderboard";

const initialNfts = [
  { id: "#0842", name: "Genesis Fox", rarity: "LEGENDARY", level: 12, power: 1850, className: "fox", symbol: "✦" },
  { id: "#0176", name: "Orbital Warden", rarity: "EPIC", level: 8, power: 1220, className: "warden", symbol: "◈" },
  { id: "#0369", name: "Lunar Scout", rarity: "RARE", level: 5, power: 760, className: "lunar", symbol: "✧" },
];

const navItems: { label: Section; icon: typeof Home }[] = [
  { label: "Dashboard", icon: Home },
  { label: "NFT Garage", icon: Image },
  { label: "Mining Pool", icon: Pickaxe },
  { label: "Quests", icon: Zap },
  { label: "Friends", icon: Users },
  { label: "Leaderboard", icon: Trophy },
];

export default function HomePage() {
  const [section, setSection] = useState<Section>("Dashboard");
  const [connected, setConnected] = useState(false);
  const [wallet, setWallet] = useState("");
  const [mining, setMining] = useState(true);
  const [claimed, setClaimed] = useState(false);
  const [questDone, setQuestDone] = useState<string[]>(["daily"]);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [toast, setToast] = useState("");

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2800);
  };

  function connectWallet() {
    const ethereum = (window as Window & { ethereum?: { request: (args: { method: string }) => Promise<string[]> } }).ethereum;
    if (!ethereum) {
      notify("No EVM wallet found. Install MetaMask to connect. This starter is UI-only.");
      return;
    }
    ethereum.request({ method: "eth_requestAccounts" })
      .then((accounts) => {
        if (accounts[0]) {
          setWallet(`${accounts[0].slice(0, 6)}…${accounts[0].slice(-4)}`);
          setConnected(true);
          notify("Wallet connected. This demo does not submit blockchain transactions.");
        }
      })
      .catch(() => notify("Wallet connection cancelled."));
  }

  const completeQuest = (id: string) => {
    if (questDone.includes(id)) return;
    setQuestDone((current) => [...current, id]);
    notify("Demo quest marked complete. No on-chain reward was issued.");
  };

  const titleMap: Record<Section, string> = {
    Dashboard: "Your NFTs. Your Power.",
    "NFT Garage": "Your collection.",
    "Mining Pool": "Put your NFTs to work.",
    Quests: "Complete quests. Earn Gems.",
    Friends: "Bring your squad.",
    Leaderboard: "Season 01 rankings.",
  };

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand"><span className="brand-mark">✦</span><span>VOID<span className="brand-accent">MINT</span></span><button className="mobile-close" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={18}/></button></div>
        <div className="menu-label">MENU</div>
        <nav className="nav-list">
          {navItems.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${section === label ? "active" : ""}`} onClick={() => { setSection(label); setMobileMenu(false); }}>
              <Icon size={18}/><span>{label}</span>{label === "Quests" && <span className="nav-dot"/>}
            </button>
          ))}
        </nav>
        <div className="sidebar-promo">
          <div className="promo-orb">◈</div>
          <p className="eyebrow">SEASON 01</p>
          <h3>More NFTs.<br/>More power.</h3>
          <p className="muted small">Collect. Level up. Explore.</p>
          <button className="round-arrow" onClick={() => setSection("NFT Garage")} aria-label="Open NFT Garage"><ArrowRight size={17}/></button>
        </div>
        <div className="sidebar-user">
          <div className="avatar">V</div><div className="user-info"><b>{connected ? "Wallet player" : "Guest player"}</b><span>Explorer · Level 1</span><div className="tiny-progress"><i/></div></div>
        </div>
      </aside>

      {mobileMenu && <button className="scrim" onClick={() => setMobileMenu(false)} aria-label="Close navigation"/>}

      <section className="main-area">
        <header className="topbar">
          <button className="mobile-menu-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={21}/></button>
          <div className="breadcrumb"><span>VOIDMINT</span><span className="crumb-slash">/</span><span>{section}</span></div>
          <div className="top-actions">
            <button className="icon-button" aria-label="Help" onClick={() => notify("VOIDMINT is currently a demo interface.")}><CircleHelp size={18}/></button>
            <button className="icon-button" aria-label="Notifications" onClick={() => notify("You’re all caught up.")}><Bell size={18}/></button>
            <button className={`wallet-button ${connected ? "connected" : ""}`} onClick={connectWallet}><Wallet size={16}/><span>{connected ? wallet : "Connect wallet"}</span><ChevronRight size={15}/></button>
          </div>
        </header>

        <div className="content">
          <section className="hero">
            <div className="hero-copy">
              <div className="eyebrow"><span className="status-dot"/> NFT GAMING ECOSYSTEM</div>
              <h1>{titleMap[section].split(".")[0]}<span className="pink-dot">.</span></h1>
              <p>Collect rare NFTs, level up, and explore passive mining on BNB Chain.</p>
            </div>
            <div className="hero-chip"><Sparkles size={15}/> DEMO SEASON</div>
          </section>

          {section === "Dashboard" && (
            <>
              <div className="top-grid">
                <article className="nft-feature panel">
                  <div className="feature-top"><span className="tag tag-pink">GENESIS</span><span className="feature-spark">✦</span></div>
                  <div className="creature creature-fox"><span>V</span><i>✦</i></div>
                  <div className="feature-bottom"><div><p className="eyebrow">YOUR FEATURED NFT</p><h2>Genesis Fox <span className="muted">#0842</span></h2><p className="muted small">Level 12 · Legendary</p></div><div className="power-value"><span>MINING POWER</span><b>1,850</b></div></div>
                </article>
                <article className="panel mining-panel">
                  <div className="panel-heading"><div className="icon-tile green"><Pickaxe size={18}/></div><div><p className="eyebrow">ACTIVE MINING POSITION</p><h3>{mining ? "Mining active" : "Mining paused"}</h3></div><span className={`status-pill ${mining ? "online" : "offline"}`}>{mining ? "ACTIVE" : "PAUSED"}</span></div>
                  <div className="mining-amount"><strong>{mining ? "0.042" : "0.000"}</strong><span>VOID <small>/ hour</small></span></div>
                  <div className="progress-track"><div className="progress-fill" style={{ width: mining ? "68%" : "0%" }}/></div>
                  <div className="mining-meta"><span><Zap size={14}/> NFT power</span><b>1,850 / 2,000</b></div>
                  <div className="mining-meta"><span><Activity size={14}/> Mining cycle</span><b>6d 12h left</b></div>
                  <button className="primary-button" onClick={() => { setMining(!mining); notify(mining ? "Demo mining paused." : "Demo mining resumed."); }}><Zap size={16}/>{mining ? "Pause demo mining" : "Resume demo mining"}<ArrowRight size={16}/></button>
                  <button className="secondary-button" onClick={() => notify("Demo only: no real VOID tokens can be claimed yet.")}><Coins size={16}/> Claim reward <span className="button-note">DEMO</span></button>
                </article>
                <article className="panel wallet-summary">
                  <div className="panel-heading"><div className="icon-tile purple"><Wallet size={18}/></div><p className="eyebrow">WALLET SUMMARY</p></div>
                  <div className="balance-line"><span className="token-icon">V</span><div><strong>1,284.50</strong><span>VOID <em>demo balance</em></span></div></div>
                  <div className="balance-line"><span className="gem-icon"><Gem size={17}/></span><div><strong>2,450</strong><span>Gems</span></div></div>
                  <div className="summary-foot"><span className={`status-dot ${connected ? "" : "dim"}`}/>{connected ? "Wallet connected" : "Preview data"}</div>
                </article>
              </div>

              <div className="section-heading"><div><p className="eyebrow">YOUR PROGRESS</p><h2>Make every session count.</h2></div><button className="text-button" onClick={() => setSection("Mining Pool")}>View mining <ArrowRight size={15}/></button></div>
              <div className="bottom-grid">
                <article className="panel quests-panel">
                  <div className="panel-title-row"><div><h3>Daily quests</h3><p className="muted small">Small tasks, steady progress.</p></div><span className="count-pill">{questDone.length}/3</span></div>
                  {[
                    { id: "daily", title: "Visit your dashboard", reward: "+50 Gems" },
                    { id: "garage", title: "Explore your NFT Garage", reward: "+75 Gems" },
                    { id: "mining", title: "Review your mining position", reward: "+100 Gems" },
                  ].map((q) => <div className="quest-row" key={q.id}><button className={`quest-check ${questDone.includes(q.id) ? "done" : ""}`} onClick={() => completeQuest(q.id)} aria-label={`Complete ${q.title}`}>{questDone.includes(q.id) ? <Check size={14}/> : <Plus size={14}/>}</button><div className="quest-copy"><b>{q.title}</b><span><Gem size={12}/> {q.reward}</span></div><span className={`quest-status ${questDone.includes(q.id) ? "complete" : ""}`}>{questDone.includes(q.id) ? "DONE" : "START"}</span></div>)}
                </article>
                <article className="panel collection-panel">
                  <div className="panel-title-row"><div><h3>Your NFT collection</h3><p className="muted small">3 demo collectibles</p></div><button className="text-button" onClick={() => setSection("NFT Garage")}>View all <ArrowRight size={15}/></button></div>
                  <div className="nft-mini-grid">{initialNfts.map(nft => <button className={`nft-mini ${nft.className}`} key={nft.id} onClick={() => setSection("NFT Garage")}><div className="mini-creature">{nft.symbol}</div><b>{nft.name}</b><span>{nft.id} · Lv.{nft.level}</span><em>{nft.rarity}</em></button>)}</div>
                </article>
                <article className="panel leaderboard-panel">
                  <div className="panel-title-row"><div><h3>Season 01 leaderboard</h3><p className="muted small">Top explorers</p></div><button className="text-button" onClick={() => setSection("Leaderboard")}>View all <ArrowRight size={15}/></button></div>
                  {[
                    ["01", "ZenFox", "12,450", "2,500"],
                    ["02", "VoidRider", "9,320", "1,800"],
                    ["03", "CryptoWolf", "8,760", "1,500"],
                    ["04", "NovaByte", "7,230", "1,200"],
                  ].map((p) => <div className="leader-row" key={p[0]}><span className="rank">{p[0]}</span><span className="leader-avatar">{p[1].slice(0,1)}</span><b>{p[1]}</b><span>{p[2]}</span></div>)}
                </article>
              </div>
            </>
          )}

          {section === "NFT Garage" && (
            <section className="panel page-panel">
              <div className="panel-title-row"><div><p className="eyebrow">COLLECTION / 03 ITEMS</p><h2>Your NFT Garage</h2><p className="muted">NFT cards shown here are sample data, not owned on-chain assets.</p></div><button className="primary-button compact" onClick={() => notify("Paid mint will be enabled after the NFT contract is deployed.")}><Plus size={16}/> Mint NFT</button></div>
              <div className="garage-grid">{initialNfts.map(nft => <article className={`garage-card ${nft.className}`} key={nft.id}><div className="garage-art"><span>{nft.symbol}</span><i>{nft.id}</i></div><div className="garage-details"><span className="tag tag-pink">{nft.rarity}</span><h3>{nft.name}</h3><p className="muted small">Level {nft.level} · {nft.power.toLocaleString()} power</p><button className="secondary-button" onClick={() => notify("Upgrade is a UI demo. No transaction submitted.")}>View NFT <ArrowRight size={15}/></button></div></article>)}</div>
            </section>
          )}

          {section === "Mining Pool" && (
            <section className="panel page-panel mining-page">
              <div className="eyebrow">SEASON 01 · MINING POOL</div><h2>Put your NFTs to work.</h2><p className="muted">Illustrative mining metrics only. No real tokens are generated by this demo.</p>
              <div className="pool-stat-grid"><div className="stat-card"><span>Reward pool</span><b>10,000,000 <small>VOID</small></b></div><div className="stat-card"><span>Pool distributed</span><b>30.8%</b></div><div className="stat-card"><span>Active positions</span><b>1,284</b></div></div>
              <div className="pool-progress"><div><span>Season reward pool</span><b>69.2% remaining</b></div><div className="progress-track"><div className="progress-fill" style={{width:"69.2%"}}/></div></div>
              <div className="panel inner-panel"><div className="panel-heading"><div className="icon-tile green"><Pickaxe size={18}/></div><div><h3>Genesis Fox · #0842</h3><p className="muted small">1,850 mining power</p></div><span className={`status-pill ${mining ? "online" : "offline"}`}>{mining ? "ACTIVE" : "PAUSED"}</span></div><div className="mining-amount"><strong>{mining ? "0.042" : "0.000"}</strong><span>VOID <small>/ hour (demo)</small></span></div><div className="progress-track"><div className="progress-fill" style={{width:mining ? "68%" : "0%"}}/></div><div className="action-row"><button className="primary-button" onClick={() => {setMining(!mining); notify(mining ? "Demo mining paused." : "Demo mining resumed.");}}>{mining ? "Pause mining demo" : "Resume mining demo"}</button><button className="secondary-button" onClick={() => {setClaimed(true); notify("Demo claim preview only. No tokens transferred.");}}>Claim preview {claimed ? "✓" : ""}</button></div></div>
            </section>
          )}

          {section === "Quests" && (
            <section className="panel page-panel"><p className="eyebrow">QUEST BOARD</p><h2>Complete quests. Earn Gems.</h2><p className="muted">Quest rewards are simulated in this preview.</p>{[{id:"daily",title:"Visit your dashboard",desc:"Check your player status.",reward:"50 Gems"},{id:"garage",title:"Explore your NFT Garage",desc:"Open your collection.",reward:"75 Gems"},{id:"mining",title:"Review your mining position",desc:"Visit the mining pool.",reward:"100 Gems"},{id:"social",title:"Join the community",desc:"Community link will be added later.",reward:"150 Gems"}].map(q=><div className="large-quest" key={q.id}><div className="icon-tile purple"><Zap size={18}/></div><div className="large-quest-copy"><b>{q.title}</b><span>{q.desc}</span><em><Gem size={13}/> {q.reward}</em></div><button className={`secondary-button ${questDone.includes(q.id) ? "is-done" : ""}`} onClick={() => completeQuest(q.id)}>{questDone.includes(q.id) ? "Completed" : "Complete demo"}</button></div>)}</section>
          )}

          {section === "Friends" && (
            <section className="panel page-panel"><p className="eyebrow">REFER & EARN</p><h2>Bring your squad.</h2><p className="muted">Referral tracking will be connected to the backend in a later version.</p><div className="referral-card"><div className="referral-icon"><Users size={28}/></div><h3>Invite friends to VOIDMINT</h3><p className="muted">Share your invite code and track eligible referrals.</p><div className="referral-code">VOIDMINT-DEMO-01 <button onClick={() => {navigator.clipboard?.writeText("VOIDMINT-DEMO-01"); notify("Demo referral code copied.");}}>Copy code</button></div></div></section>
          )}

          {section === "Leaderboard" && (
            <section className="panel page-panel"><p className="eyebrow">SEASON 01</p><h2>Explorer leaderboard.</h2><p className="muted">Sample rankings for the UI preview.</p><div className="leaderboard-full">{[["01","ZenFox","12,450","2,500"],["02","VoidRider","9,320","1,800"],["03","CryptoWolf","8,760","1,500"],["04","NovaByte","7,230","1,200"],["05","LunaRex","6,890","1,000"]].map(p=><div className="leader-full-row" key={p[0]}><span className="rank">{p[0]}</span><div className="leader-avatar">{p[1][0]}</div><b>{p[1]}</b><span className="leader-power">{p[2]} power</span><span className="leader-reward"><Gem size={14}/>{p[3]}</span></div>)}</div></section>
          )}

          <footer className="footer"><span>© 2026 VOIDMINT · Community-built demo</span><span><ShieldCheck size={13}/> Never share your seed phrase</span><span>BNB Chain concept</span></footer>
        </div>
      </section>
      {toast && <div className="toast"><Check size={16}/>{toast}</div>}
    </main>
  );
}
