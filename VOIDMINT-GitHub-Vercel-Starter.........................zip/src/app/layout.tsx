import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "VOIDMINT — NFT Gaming & Mining",
  description: "Collect NFTs, level up, and explore the VOIDMINT mining demo.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
